
import languageModel from "../../../utils/languageModel";
function ServeLangItem() {
    const langCntnt = languageModel();
    return langCntnt && langCntnt;
}
export default ServeLangItem;